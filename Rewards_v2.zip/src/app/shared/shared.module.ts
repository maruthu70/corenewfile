import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FilterBarComponent } from './filter-bar.component';
import { SubMenuComponent } from './submenu.component';
import { LoaderComponent } from './loader.component';

import { MatSelectModule } from '@angular/material/select';

@NgModule({
    imports: [
        CommonModule, MatSelectModule
    ],
    declarations: [FilterBarComponent, SubMenuComponent,LoaderComponent],
    exports: [FilterBarComponent, SubMenuComponent,LoaderComponent]
})
export class SharedModule { }