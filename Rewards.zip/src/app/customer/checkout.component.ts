import { Component } from '@angular/core';

@Component({
    selector: 'card-checkout',
    template: `        
    
        <div class="container-fluid">
            <div class="row">
            <div style="margin-left:2%;font-weight:bold;">Gift Card --> Department Store</div>
                <div class="col-lg-6 cardViewer">
                    <div class="row">
                        <div class="col-lg-7">
                            <img src="assets/images/c3.jpg" style="max-width:100%;max-height:200px;">
                        </div>
                        <div class="col-lg-5">
                            <div style="font-size:20px;font-weight:bold;">Walmart Gift Card</div>
                            <div style="font-family: sans-serif; font-size: 16px;">Starting 2500 , (10%
                                discount)</div>


                            <div class="row">
                                <div class="col-lg-3">
                                    <div class="bars">$25</div>
                                    <div class="glyphicon glyphicon-star"><span>2500</span></div> 
                                    <div class="decrementer">-</div>                                                       
                                </div>                                                        
                                <div class="col-lg-3 col-lg-offset-1">
                                    <div class="bars">$25</div>
                                    <div class="glyphicon glyphicon-star"><span>2500</span></div>  
                                    <div class="decrementer">2</div>                                                      
                                 </div>
                                <div class="col-lg-3 col-lg-offset-1">
                                    <div class="bars">$25</div>
                                    <div class="glyphicon glyphicon-star"><span>2500</span></div>
                                    <div class="decrementer">+</div>                                                        
                                </div>                                                     
                            </div>

                            <div class="cart">Add to Cart</div>
                        </div>

                        

                    </div>
                </div>
            </div>
        </div>



    `
    ,
    styles: [`
    .cart
    {
        font-size: 20px;
    padding-top: 5%;
    text-align: center;
        margin-top:10%;
        height:55px;
        width:155px;
        background-color:darkorange;
        color:white;
    }
    .decrementer
    {
        border:1px solid grey;
        min-height:29px;min-width:70px;margin-top:30%;padding-left:58%;padding-top:5%;
    }
    .bars
    {
        min-height:25px;background-color:gold;
font-weight:bold;padding-top:11%;min-width:70px;padding-left:45%;
    }
.cardViewer
{
    margin-top:2%;
}
.glyphicon
{
    color:gold;
}
div span
{
    color:#000;font-weight:bold;font-size:18px;
}
  `]

})
export class CardCheckoutComponent {
    title = 'app';
}
