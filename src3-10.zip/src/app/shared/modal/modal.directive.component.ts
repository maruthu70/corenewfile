import { Directive, ViewContainerRef } from '@angular/core';

@Directive({
    selector: '[modal-dir]',
})
export class ModalDirective {
    constructor(public viewContainerRef: ViewContainerRef) { }
}