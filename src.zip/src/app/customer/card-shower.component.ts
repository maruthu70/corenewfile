import { Component } from '@angular/core';
import { Route, Router } from '@angular/router';

@Component({
  selector: 'card-shower',
  templateUrl: './card-shower.component.html',
  styleUrls: ['./card-shower.component.css']
})
export class CardComponent {

  constructor(private route: Router) {

  }
  cards: any = [{
    url: 'assets/cards/c1.png',
    denomination: { rewards: 100, cash: 10 }
  },
  {
    url: 'assets/cards/c5.png',
    denomination: { rewards: 150, cash: 12 }
  },
  {
    url: 'assets/cards/c3.jpg',
    denomination: { rewards: 50, cash: 20 }
  },
  {
    url: 'assets/cards/c4.jpg',
    denomination: { rewards: 100, cash: 30 }
  },
  {
    url: 'assets/cards/c4.jpg',
    denomination: { rewards: 100, cash: 30 }
  }
  ]

  isLoading = false;
  checkOut(p) {
    let request = new Card({ url: p.url, rewards: p.denomination.rewards, cash: p.denomination.cash });
    console.log(p);
    console.log(request)
    this.isLoading = true;
    setTimeout(() => {
      this.route.navigate(['/customer/home/checkout'], { queryParams: request })
    }, 2000);

  }

}

export class Card {
  url: string;
  rewards: number;
  cash: number
  constructor(obj) {
    this.url = obj && obj.url || '';
    this.rewards = obj && obj.rewards || ''
    this.cash = obj && obj.cash || ''
  }
}