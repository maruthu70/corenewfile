import { Component } from '@angular/core';
import { Route, Router, ActivatedRoute } from '@angular/router';
import { DataService } from '../core/service'
import { v } from '@angular/core/src/render3';

@Component({
    selector: 'card-checkout',
    template: `        
    
        <div class="container-fluid">
            <div class="row" *ngIf="!isLoading">
            <div style="margin-left:2%;font-weight:bold;">Gift Card --> Check Out</div>
                <div class="col-lg-6 cardViewer">
                    <div class="row">
                        <div class="col-lg-7" style="text-align:center;">
                            <img [src]="card.url" style="max-width:100%;max-height:200px;">
                        </div>
                        <div class="col-lg-5">
                            <div style="font-size:20px;font-weight:bold;">Walmart Gift Card</div>
                            <div style="font-family: sans-serif; font-size: 16px;">Starting 2500 , (10%
                                discount)</div>


                            <div class="row">
                                <div class="col-lg-3">
                                    <div class="bars">$ {{card.cash}}</div>
                                    <div class="glyphicon glyphicon-star"><span>{{card.rewards}}</span></div> 
                                    <div class="decrementer" (click)="quantityCount('-')">-</div>                                                       
                                </div>                                                        
                                <div class="col-lg-3 col-lg-offset-1">
                                    <div class="bars" style="visibility:hidden;">$ {{card.cash*2}}</div>
                                    <div style="visibility:hidden;" class="glyphicon glyphicon-star"><span>{{card.rewards*2}}</span></div>  
                                    <div class="decrementer">{{quantity}}</div>                                                      
                                 </div>
                                <div class="col-lg-3 col-lg-offset-1">
                                    <div style="visibility:hidden;" class="bars">$ {{card.cash*5}}</div>
                                    <div style="visibility:hidden;" class="glyphicon glyphicon-star"><span> {{card.rewards*5}}</span></div>
                                    <div class="decrementer" (click)="quantityCount('+')">+</div>                                                        
                                </div>                                                     
                            </div>

                            <div class="cart" (click)="addToCart()">Check Out</div>
                            <div id="cart_error" style="color:red;font-weight:bold;display:none">In-Sufficient Balance in Account.</div>
                        </div>

                        

                    </div>
                </div>
            </div>
<ng-container *ngIf="isLoading">
<div style="margin-left:45%;">
<loading></loading>
</div>
</ng-container>

        </div>


        <button type="button" id="success" class="btn btn-info btn-lg" data-toggle="modal" style="visibility:hidden;" data-target="#success_tic">Open Modal</button>

   
<div id="success_tic" class="modal fade" role="dialog">
<div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
        <a class="close" href="#" data-dismiss="modal">&times;</a>
        <div class="page-body">
            <div class="head">
                <h3 style="margin-top:5px;">Purchase Successful</h3>
                <h4>Your remaining balance:XXX</h4>
            </div>

            <h1 style="text-align:center;">
                <div class="checkmark-circle">
                    <div class="background"></div>
                    <div class="checkmark draw"></div>
                </div>
            </h1>

        </div>
    </div>
</div>

</div>

    `
    ,
    styleUrls: ['./card-shower.component.css']

})
export class CardCheckoutComponent {

    constructor(private aRoute: ActivatedRoute, private data: DataService) {

    }
    card = {}; quantity = 1; isLoading = false;
    ngOnInit() {
        this.aRoute.queryParams.subscribe(v => {
            console.log(v);
            this.card = v;
        })
    }
    quantityCount(p) {
        if (p == '+') {
            ++this.quantity
        }
        else {
            if (this.quantity > 1) {
                --this.quantity;
            }
            else {
                alert("Minimum One product is must");
            }
        }

    }

    addToCart() {
        this.isLoading = true;
        this.data.getUsersReward().subscribe(v => {
            console.log('yes in')
            console.log(v);
            if (v['rewardpoints'] <= this.card['rewards']) {
                this.data.purchase(this.card['rewards'] * this.quantity).subscribe(d => {
                    document.getElementById("success").click();
                }, err => {
                    this.isLoading = false;
                    setTimeout(() => {
                        document.getElementById('cart_error').style.display = 'block';
                        document.getElementById('cart_error').textContent = 'Error occured. Try again later. \n Sorry for the inconvenience'
                    }, 0)
                })
            }
            else {
                document.getElementById('cart_error').style.display = 'block';
            }
        }, err => {
            this.isLoading = false;
            setTimeout(() => {
                document.getElementById('cart_error').style.display = 'block';
                document.getElementById('cart_error').textContent = 'Error occured. Try again later. \n Sorry for the inconvenience'
                //document.getElementById("success").click();
            }, 0)

        })
    }

}
