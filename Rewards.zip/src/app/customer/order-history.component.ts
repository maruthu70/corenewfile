import { Component } from '@angular/core';

@Component({
    selector: 'order-history',
    templateUrl: './order-history.component.html',
    styles: [`./order-history.component.css`]

})
export class OrderHisotryComponent {
    title = 'app';
}
