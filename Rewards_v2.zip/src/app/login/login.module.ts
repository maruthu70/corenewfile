import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LoginRouting } from './login.routing.module'
import { SharedModule } from '../shared/shared.module';
import { ChartsModule } from 'ng2-charts';
import { LoginComponent } from './home.component';
import { LoginHeaderComponent } from './login-header.component';
@NgModule({
    imports: [
        CommonModule, LoginRouting, SharedModule, ChartsModule
    ],
    declarations: [LoginComponent, LoginHeaderComponent]
})
export class LoginModule { }