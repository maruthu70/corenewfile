import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BankerRouting } from './banker.routing.module';
import { CustomerHomeComponent } from './home.component';
import { BankerHeaderComponent } from './banker-header.component';
import { VendorComponent } from './vendor.component';
import { ReportComponent } from './report.component';
import { CustomerComponent } from './customer.component';
import { SharedModule } from '../shared/shared.module';
import { ChartsModule } from 'ng2-charts';
@NgModule({
    imports: [
        CommonModule, BankerRouting, SharedModule, ChartsModule
    ],
    declarations: [ReportComponent, CustomerHomeComponent, BankerHeaderComponent, CustomerComponent, VendorComponent]
})
export class BankerModule { }