import { Component } from '@angular/core';

@Component({
  selector: 'login-header',
  templateUrl: './login-header.component.html',
  styleUrls: ['./login-header.component.css','../core/glyphicon-circle.css']
})
export class LoginHeaderComponent {
  title = 'app';
}
