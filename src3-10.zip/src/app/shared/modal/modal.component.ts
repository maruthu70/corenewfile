import { Component, Input, OnInit, ViewChild, ComponentFactoryResolver, OnDestroy } from '@angular/core';


import { ModalDirective } from './modal.directive.component';

@Component({
    selector: 'modal-customize',
    template: `
              <div class="modaler">
                <h3>Advertisements</h3>
                <ng-template modal-dir></ng-template>
              </div>
            `
})
export class ModalComponent implements OnInit {
    @Input() inP: any;
    @ViewChild(ModalDirective) modalAccessor: ModalDirective;
    interval: any;

    constructor(private componentFactoryResolver: ComponentFactoryResolver) { }

    ngOnInit() {
        this.loadComponent();
        console.log(this.inP.component);
    }


    data = {};
    loadComponent() {
        const componentFactory = this.componentFactoryResolver.resolveComponentFactory(this.inP.component);
        const viewContainerRef = this.modalAccessor.viewContainerRef;
        viewContainerRef.clear();

        const componentRef = viewContainerRef.createComponent(componentFactory);
        this.data = this.inP.data;
        console.log(this.data);
    }


}
