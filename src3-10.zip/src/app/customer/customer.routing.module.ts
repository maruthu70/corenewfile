import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CustomerHomeComponent } from './home.component'
import { CardComponent } from './card-shower.component';
import { CardCheckoutComponent } from './checkout.component';
import { OrderHisotryComponent } from './order-history.component';
const routes: Routes = [
    {
        path: 'home', component: CustomerHomeComponent, children: [{
            path: 'cards', component: CardComponent
        },
        {
            path: 'checkout', component: CardCheckoutComponent
        },
        {
            path: 'order', component: OrderHisotryComponent
        }
        ]
    }

];

@NgModule({
    imports: [
        RouterModule.forChild(routes)
    ],
    exports: [
        RouterModule
    ]
})

export class CustomerRouting {
}