import { Component } from '@angular/core';

@Component({
  selector: 'customer-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class CustomerHomeComponent {
  title = 'app';
}
