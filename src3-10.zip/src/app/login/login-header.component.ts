import { Component } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { addCustomerComponent } from '../shared/add.customer.component';
import { addVendorComponent } from '../shared/add.vendor.component';

@Component({
  selector: 'login-header',
  templateUrl: './login-header.component.html',
  styleUrls: ['./login-header.component.css', '../core/glyphicon-circle.css']
})
export class LoginHeaderComponent {
  title = 'app';

  constructor(public dialog: MatDialog) {

  }
  nav(p) {
    //if
    let componentName: any = (p == 'cn') ? addCustomerComponent : addVendorComponent;
    const dialogRef = this.dialog.open(componentName, {

    });

    dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed');

    });
  }
}
