import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FilterBarComponent } from './filter-bar.component';
import { SubMenuComponent } from './submenu.component';
import { LoaderComponent } from './loader.component';

import { MatSelectModule } from '@angular/material/select';
import { FormsModule } from '@angular/forms';
import { addCustomerComponent } from './add.customer.component';
import { addVendorComponent } from './add.vendor.component';
import { ModalDirective } from './modal/modal.directive.component';
import { ModalComponent } from './modal/modal.component';

@NgModule({
    imports: [
        CommonModule, MatSelectModule,FormsModule
    ],
    declarations: [addVendorComponent, ModalComponent, FilterBarComponent, SubMenuComponent, LoaderComponent, addCustomerComponent, ModalDirective, ModalComponent],
    exports: [addVendorComponent, FilterBarComponent, SubMenuComponent, LoaderComponent, addCustomerComponent, ModalComponent],
    entryComponents: [addCustomerComponent, addVendorComponent]
})
export class SharedModule { }