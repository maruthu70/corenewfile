import { Component } from '@angular/core';
import { Router } from '@angular/router'
@Component({
  selector: 'menu-bar',
  templateUrl: './submenu.component.html',
  styleUrls: ['./submenu.component.css']
})
export class SubMenuComponent {
  title = 'app';
  constructor(private Route: Router) { }
  navigate(p) {
    if (p == 'v')
      this.Route.navigate(['/banker/home/vendor'])
    else if (p == 'c')
      this.Route.navigate(['/banker/home/details'])
    else this.Route.navigate(['/banker/home/report'])
  }
}
