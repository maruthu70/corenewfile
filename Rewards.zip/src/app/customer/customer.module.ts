import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CustomerRouting } from './customer.routing.module';
import { CustomerHomeComponent } from './home.component';
import { CustomerHeaderComponent } from './customer-header.component';
import { CardComponent } from './card-shower.component';
import { CardCheckoutComponent } from './checkout.component';
import { OrderHisotryComponent } from './order-history.component';
import { SharedModule } from '../shared/shared.module'
@NgModule({
    imports: [
        CommonModule, CustomerRouting, SharedModule
    ],
    declarations: [CustomerHomeComponent, CustomerHeaderComponent, CardComponent, CardCheckoutComponent, OrderHisotryComponent]
})
export class CustomerModule { }