import { Component } from '@angular/core';
import { ChartDataSets,ChartType, ChartOptions } from 'chart.js';
import { Color, BaseChartDirective, Label } from 'ng2-charts';

@Component({
    selector: 'report',
    templateUrl: './report.component.html',
    styleUrls: [`./report.component.css`]

})
export class ReportComponent {
    
    //Bar chart

    public barChartOptions: ChartOptions = {
        responsive: true,
        // We use these empty structures as placeholders for dynamic theming.
        scales: { xAxes: [{}], yAxes: [{}] },
        plugins: {
          datalabels: {
            anchor: 'end',
            align: 'end',
          }
        }
      };
      public barChartLabels: Label[] = ['2006', '2007', '2008', '2009', '2010', '2011', '2012'];
      public barChartType: ChartType = 'bar';
      public barChartLegend = true;
      //public barChartPlugins = [pluginDataLabels];
    
      public barChartData: ChartDataSets[] = [
        { data: [65, 59, 80, 81, 56, 55, 40], label: 'Series A' },
        { data: [28, 48, 40, 19, 86, 27, 90], label: 'Series B' }
      ];


    //Line Chart
    public lineChartData: ChartDataSets[] = [
        { data: [65, 59, 80, 81, 56, 55, 40], label: 'Series A' },{ data: [25, 59, 84, 21, 56, 95, 40], label: 'Series A' },
      ];
      public lineChartLabels: Label[] = ['January', 'February', 'March', 'April', 'May', 'June', 'July'];
    
      public lineChartColors: Color[] = [
        {
          borderColor: 'black',
          backgroundColor: 'rgba(255,0,0,0.3)',
        },
      ];
      public lineChartLegend = true;
      public lineChartType = 'line';
      public lineChartPlugins = [];
    
    
    
    title = 'app';

    statementHeaders = ['Purchange Date', 'Customer ID', 'Customer Name', 'Product Type','Product', 'Quantity', 'Order Status', 'Points Used']
    redemptionHeaders = ['Invoice ID', 'Invoice Date', 'Redeemed Rewards', 'Invoice Cost','Status']
    headers = this.statementHeaders;
    displayTable(p) {
        this.headers = p == 'stt' ? this.statementHeaders : this.redemptionHeaders;
    }
}
