import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';


const routes: Routes = [
    {
        path: 'customer', loadChildren: './customer/customer.module#CustomerModule'
    },
    {
        path: 'banker', loadChildren: './bankers/banker.module#BankerModule'
    },
    {
        path: 'login', loadChildren: './login/login.module#LoginModule'
    },
    {
        path: '', redirectTo: 'customer/home/cards', pathMatch: 'full'
    }

];

@NgModule({
    imports: [
        RouterModule.forRoot(routes)
    ],
    exports: [
        RouterModule
    ]
})

export class AppRoutingModule {
}