import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FilterBarComponent } from './filter-bar.component';
import { SubMenuComponent } from './submenu.component';

import { MatSelectModule } from '@angular/material/select';

@NgModule({
    imports: [
        CommonModule, MatSelectModule
    ],
    declarations: [FilterBarComponent, SubMenuComponent],
    exports: [FilterBarComponent, SubMenuComponent]
})
export class SharedModule { }