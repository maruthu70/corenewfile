import { Component } from '@angular/core';
import { Route, Router, ActivatedRoute } from '@angular/router';
import { DataService } from '../core/service'
import { v } from '@angular/core/src/render3';

@Component({
    selector: 'loading',
    template: `        
    
        <div class="container-fluid">
        <div class="loader"></div>
        </div>


    `
    ,
    styles: [`
    .loader {
        border: 10px solid #f3f3f3;
        border-radius: 50%;
        border-top: 10px solid rgb(0,123,234);
        /*border-left: 16px solid rgb(0,123,234);*/
        border-bottom: 10px solid rgb(0,123,234);
        width: 120px;
        height: 120px;margin-top:5%;
        -webkit-animation: spin 2s linear infinite;
        animation: spin 2s linear infinite;
      }
      
      @-webkit-keyframes spin {
        0% { -webkit-transform: rotate(0deg); }
        100% { -webkit-transform: rotate(360deg); }
      }
      
      @keyframes spin {
        0% { transform: rotate(0deg); }
        100% { transform: rotate(360deg); }
      }
  `]

})
export class LoaderComponent {

    constructor(private aRoute: ActivatedRoute, private data: DataService) {

    }

}
