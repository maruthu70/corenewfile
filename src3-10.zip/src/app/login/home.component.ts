import { Component } from '@angular/core';
import { DataService } from '../core/service';
import { Route, Router } from '@angular/router';

import { addCustomerComponent } from '../shared/add.customer.component';
import { addVendorComponent } from '../shared/add.vendor.component';

@Component({
  selector: 'login',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class LoginComponent {
  dynamicLoader = { component: addVendorComponent, data: { name: 'muthutest' } }
  title = 'app';
  userid = '';
  pwd = ''; message = false; isLoading = false;
  constructor(private DataService: DataService, private route: Router) {

  }
  ctype = '';
  login() {
    //alert(this.userid + this.pwd);
    this.isLoading = true;
    this.DataService.getUser(this.userid, this.pwd).subscribe(v => {
      console.log(v);
      if (v.length > 0) {
        this.DataService.userDetails = v[0];
        console.log(this.DataService.userDetails);
        setTimeout(() => {
          if (this.ctype == 'b')
            this.route.navigate(['/banker/home/details']);
          else {
            this.route.navigate(['/customer/home/cards']);
          }
          //this.isLoading = false;
        }, 2000);
      }
      else if (v.length == 0) {
        this.message = true;
        this.isLoading = false;
        console.log("user not found");
      }
    }, err => {
      console.log("Error occures");
    })
  }
}
