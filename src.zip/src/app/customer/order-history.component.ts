import { Component } from '@angular/core';
import { DataService } from '../core/service'

@Component({
    selector: 'order-history',
    templateUrl: './order-history.component.html',
    styles: [`./order-history.component.css`]

})
export class OrderHisotryComponent {
    title = 'app';
    constructor(private ds: DataService) { }
    ngOnInit() {
        this.ds.getCustomerORderHistory().subscribe(v => {
            console.log(v);
        }, err => {
            console.log(err);
        })
    }
}
