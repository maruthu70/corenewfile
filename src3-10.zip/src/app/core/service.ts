import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';  // Import it up here

import { map, filter, catchError } from 'rxjs/operators'
import { throwError } from 'rxjs'
@Injectable({
    providedIn: 'root'
})
export class DataService {

    constructor(private http: HttpClient) { }
    getCustomerORderHistory() {
        // return this.http.get('http://localhost:3000/api/Customer?Purchase=%7B%22customerID%22%3A%22' + this.userDetails['custid'] + '%22%7D')
        return this.http.get('assets/customer_order_history.json').pipe(
            map(v => { console.log(v); return v }),
            catchError(v => throwError(v))
        )
    }

    getUsersReward() {
        return this.http.get('http://localhost:3000/api/Customer?filter=%7B%22customerID%22%3A%22' + this.userDetails['custid'] + '%22%7D')
    }

    // getCustomerOrderHistory() {
    //     return this.http.get('assets/customer_order_history.json').pipe(
    //         map(v => { console.log(v); return v }),
    //         catchError(v => throwError(v))
    //     )
    // }

    purchase(rwd, quantity) {
        return this.http.post('http://localhost:3000/api/Purchase', {
            "$class": "org.bank.rewards.Purchase",
            "vendor": "vendor1",
            "customer": this.userDetails['custid'],
            "rewardsUsed": rwd,
            "ConvertionRate": "1",
            "usedProduct": "GIFTCARD",
            "transactionDate": "03092019",
            "orderID": "GOLD" + new Date().getTime(),
            "status": "PROCESSING",
            "transactionId": "",
            "timestamp": "2019-09-03T14:41:01.672Z"
        })
    }

    userDetails = {};

    getUser(userid, pwd) {
        return this.http.get('assets/login.json').pipe(
            map(v => { console.log(v); return v['customers'].filter(v => v['username'] == userid && v['password'] == pwd) }),
            catchError(v => throwError(v))
        )
    }

    createCustomer(username, userid, address, zip, rewards) {

        let request = {
            "$class": "org.bank.rewards.Customer",
            "customerID": "cust1",
            "name": "JohnMathew Willson",
            "address": {
                "$class": "org.bank.rewards.Address",
                "addressLine1": "Addr1",
                "addressLine2": "Addr2",
                "city": "city",
                "state": "state",
                "zip": 522001
            },
            "rewardsBalance": 1500
        }
        return this.http.post('http://localhost:3000/api/Customer', request);

    }



    createVendor(username, userid, address, zip, rewards) {
        let request = {
            "$class": "org.bank.rewards.Vendor",
            "vendorID": "vendor1",
            "vendorName": "vendor1",
            "transCurrency": "USD",
            "convertionRate": 1,
            "rewardsBalance": 2000
        }
        return this.http.post('http://localhost:3000/api/Vendor', request);
    }

}