import { Component } from '@angular/core';

@Component({
  selector: 'customer-header',
  templateUrl: './customer-header.component.html',
  styleUrls: ['./customer-header.component.css','../core/glyphicon-circle.css']
})
export class CustomerHeaderComponent {
  title = 'app';
}
