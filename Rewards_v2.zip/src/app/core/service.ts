import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';  // Import it up here

@Injectable({
    providedIn: 'root'
})
export class DataService {

    constructor(private http: HttpClient) { }

    getUsersReward() {
        return this.http.get('http://localhost:3000/api/Customer?filter=%7B%22customerID%22%3A%22ramana%22%7D')
    }

    purchase(rwd) {
        return this.http.post('http://localhost:3000/api/Purchase', {
            "$class": "org.bank.rewards.Purchase",
            "vendor": "epsilon",
            "customer": "ramana",
            "rewardsUsed": rwd,
            "ConvertionRate": "1",
            "usedProduct": "GIFTCARD",
            "transactionDate": "03092019",
            "orderID": "ord1",
            "status": "PROCESSING",
            "transactionId": "",
            "timestamp": "2019-09-03T14:41:01.672Z"
        })
    }
}