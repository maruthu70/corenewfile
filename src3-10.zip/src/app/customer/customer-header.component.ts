import { Component } from '@angular/core';
import { Route, Router } from '@angular/router';
import { DataService } from '../core/service'

@Component({
  selector: 'customer-header',
  templateUrl: './customer-header.component.html',
  styleUrls: ['./customer-header.component.css', '../core/glyphicon-circle.css']
})
export class CustomerHeaderComponent {
  title = 'app';
  constructor(private route: Router, private servicer: DataService) {

  }
  moveHistory() {
    this.route.navigate(['/customer/home/order']);
  }
  seeCards() {
    this.route.navigate(['/customer/home/cards']);
  }
  logoff() {
    this.servicer.userDetails = {};
    this.route.navigate(['login/home']);
  }
}
