import { Component } from '@angular/core';

@Component({
  selector: 'card-shower',
  templateUrl: './card-shower.component.html',
  styleUrls: ['./card-shower.component.css']
})
export class CardComponent {
  title = 'app';
}
