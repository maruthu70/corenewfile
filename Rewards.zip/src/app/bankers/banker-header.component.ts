import { Component } from '@angular/core';

@Component({
  selector: 'banker-header',
  templateUrl: './banker-header.component.html',
  styleUrls: ['./banker-header.component.css','../core/glyphicon-circle.css']
})
export class BankerHeaderComponent {
  title = 'app';
}
