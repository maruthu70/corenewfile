import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AuthGuard } from './core/AuthGuard'

const routes: Routes = [
    {
        path: 'customer', loadChildren: './customer/customer.module#CustomerModule',
        canActivate: [AuthGuard]
    },
    {
        path: 'banker', loadChildren: './bankers/banker.module#BankerModule',
        canActivate: [AuthGuard]
    },
    {
        path: 'login', loadChildren: './login/login.module#LoginModule'
    },
    {
        path: '', redirectTo: 'login/home', pathMatch: 'full'
    }

];

@NgModule({
    imports: [
        RouterModule.forRoot(routes)
    ],
    exports: [
        RouterModule
    ]
})

export class AppRoutingModule {
}