import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './home.component'
import { LoginHeaderComponent } from './login-header.component'

const routes: Routes = [
    {
        path: 'home', component: LoginComponent, children: [{
            path: '', component: LoginHeaderComponent
        }

        ]
    }

];

@NgModule({
    imports: [
        RouterModule.forChild(routes)
    ],
    exports: [
        RouterModule
    ]
})

export class LoginRouting {
}