import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CustomerHomeComponent } from './home.component'
import { VendorComponent } from './vendor.component';
import { CustomerComponent } from './customer.component';
import { ReportComponent } from './report.component';
const routes: Routes = [
    {
        path: 'home', component: CustomerHomeComponent, children: [{
            path: 'details', component: CustomerComponent
        },
        {
            path: 'vendor', component: VendorComponent
        },
        {
            path: 'report', component: ReportComponent
        }

        ]
    }

];

@NgModule({
    imports: [
        RouterModule.forChild(routes)
    ],
    exports: [
        RouterModule
    ]
})

export class BankerRouting {
}