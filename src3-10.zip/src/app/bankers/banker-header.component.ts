import { Component } from '@angular/core';
import { Route, Router } from '@angular/router';
import { DataService } from '../core/service'

@Component({
  selector: 'banker-header',
  templateUrl: './banker-header.component.html',
  styleUrls: ['./banker-header.component.css', '../core/glyphicon-circle.css']
})
export class BankerHeaderComponent {
  title = 'app';
  constructor(private route: Router, private servicer: DataService) {

  }
  logoff() {
    this.servicer.userDetails = {};
    this.route.navigate(['login/home']);
  }
}
