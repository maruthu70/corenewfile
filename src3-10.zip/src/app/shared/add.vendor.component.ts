
import { Component, Input, OnInit, ViewChild, ComponentFactoryResolver, OnDestroy } from '@angular/core';
import { DataService } from '../core/service';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';

@Component({
    selector: 'add-vendor',
    template: `
              <div class="wrapperAC">

              <div style="min-width:400px;margin:auto">
              <h2 style="visibility: visible;">Create Vendor</h2>
              <div class="input-container" style="margin-top:4%;">
                  <i class="fa fa-user icon"></i>
                  <input class="input-field" type="text" [(ngModel)]="username" placeholder="Vendor Name" name="usrnm">
              </div>

              <div class="input-container">
                  <i class="fa fa-id-badge icon"></i>
                  <input class="input-field" type="text" [(ngModel)]="userid" placeholder="Vendor ID" name="usrnm">
              </div>

              <div class="input-container">
              <i class="fa fa-address-card icon"></i>
              <input class="input-field" type="text" [(ngModel)]="ccy" placeholder="Trans Currency " name="usrnm">
          </div>

              <div class="input-container">
                  <i class="fa fa-street-view icon"></i>
                  <input class="input-field" type="text" [(ngModel)]="rate" placeholder="Conversion Rate" name="usrnm">
              </div>

              <div class="input-container">
                  <i class="fa fa-check-square icon"></i>
                  <input class="input-field" type="text" [(ngModel)]="rewards" placeholder="Reward Balance" name="usrnm">
              </div>



            
            
              <label *ngIf="error" style="color:red;">{{errmessage}}</label>
              <div class="" *ngIf="loading"> <img src="assets/images/loading.gif" style="height:50px;"></div>
              <div style="text-align: center;width:50%;margin-left:20%">
                  <button type="button" class="btn" (click)="createCus()">Create</button>
              </div>



          </div>


              </div>
            `,
    styleUrls: ['../login/home.component.css']
})
export class addVendorComponent {
    userid = '';
    rate = ''; /*Rate*/
    rewards = '';
    username = '';
    ccy = '';/*ccy*/ error = false; errmessage = ''; loading = false;
    createCus() {
        if (this.userid == "" || this.rate == '' || this.rewards == '' || this.username == '' || this.ccy == '') {
            this.error = true;
            this.errmessage = "All are mandatory fields";
        }
        else {
            this.error = false; this.loading = true;
            this.DataService.createVendor(this.username, this.userid, this.ccy, this.rate, this.rewards).subscribe(v => {
                console.log("Vendor Created successfuly");
                this.errmessage = "Vendor Created Successfully";
                this.error = true; this.loading = false;
                setTimeout(() => {
                    this.dialogRef.close();
                }, 3000);
            }, err => {
                this.errmessage = "Error Occured. Try again later";
                this.error = true; this.loading = false;
                setTimeout(() => {
                    this.dialogRef.close();
                }, 3000);
            })
        }

    }

    constructor(private DataService: DataService, public dialogRef: MatDialogRef<addVendorComponent>) {

    }
}
