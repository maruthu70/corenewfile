import { Component } from '@angular/core';

@Component({
    selector: 'vendor-details',
    templateUrl: './vendor.component.html',
    styles: [`./vendor.component.css`]

})
export class VendorComponent {
    title = 'app';

    statementHeaders = ['Purchange Date', 'Customer ID', 'Customer Name', 'Product Type','Product', 'Quantity', 'Order Status', 'Points Used']
    redemptionHeaders = ['Invoice ID', 'Invoice Date', 'Redeemed Rewards', 'Invoice Cost','Status']
    headers = this.statementHeaders;
    displayTable(p) {
        this.headers = p == 'stt' ? this.statementHeaders : this.redemptionHeaders;
    }
}
