import { Component } from '@angular/core';

@Component({
    selector: 'customer-details',
    templateUrl: './customer.component.html',
    styles: [`./customer.component.css`]

})
export class CustomerComponent {
    title = 'app';

    statementHeaders = ['Purchange Date', 'Vendor', 'Product Type', 'Product', 'Quantity', 'Order Status', 'Points Used']
    redemptionHeaders = ['Statement Date', 'Previous Balance', 'Rewards Earned', 'currentBalance']
    headers = this.statementHeaders;
    displayTable(p) {
        this.headers = p == 'stt' ? this.statementHeaders : this.redemptionHeaders;
    }
}
